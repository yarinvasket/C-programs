#pragma once
#include "ListNode.h"
bool hasNext(ListNode* node) {
	return false;
}
void* addNode(ListNode* head, void* value) {
	return &head;
}