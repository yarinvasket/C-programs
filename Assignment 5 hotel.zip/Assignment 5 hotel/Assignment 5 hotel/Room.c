#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include "Room.h"
Room* newRoom(int people, int breakfastPeople) {
	Room room = { false,people,breakfastPeople };
	return &room;
}