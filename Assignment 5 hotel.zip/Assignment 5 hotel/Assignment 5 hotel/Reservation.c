#include "Room.h"
#include "Customer.h"
#include "Reservation.h"
#include "Hotel.h"
#include <stdlib.h>
#include <stdbool.h>

Reservation* newReservation(char date[DATE_FORMAT_LENGTH], Customer* customer, int peopleInRoom, int breakfastPeople, Room* room) {
	Reservation reser = {"        ",customer,peopleInRoom,breakfastPeople,room};
	strcpy_s(reser.date, DATE_FORMAT_LENGTH, date);
	return &reser;
}